<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Models\Cutsomer;
use App\Models\Order;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CustomerOrderController extends Controller
{
    public $user;
    public $customer;
    public $order;

    public function __construct()
    {
        $this->user = new User();
        $this->customer = new Cutsomer();
        $this->order = new Order();
    }
    public function index()
    {
        $orders = $this->order->where('customer_id',Auth::user()->customer->id)->whereIn('status',[0,1,2,3,4,5,6])->latest()->paginate(10);
        $search = false;
        $search_value = null;
        return view('dashboard.customer_order.index',compact('orders','search','search_value'));
    }
    
    public function search(Request $request)
    {
        $orders = $this->order->where('customer_id',Auth::user()->customer->id)->where('name','LIKE','%'.$request->search_value.'%')->whereIn('status',[0,1,2,3,4,5,6])->latest()->paginate(10);
        $search = true;
        $search_value = $request->search_value;
        return view('dashboard.customer_order.index',compact('orders','search','search_value'));
    }
    public function waiting()
    {
        $orders = $this->order->where('customer_id',Auth::user()->customer->id)->where('status',0)->latest()->paginate(10);
        $search = false;
        $search_value = null;
        return view('dashboard.customer_order.index',compact('orders','search','search_value'));
    }
    public function onWay()
    {
        $orders = $this->order->where('customer_id',Auth::user()->customer->id)->where('status',1)->latest()->paginate(10);
        $search = false;
        $search_value = null;
        return view('dashboard.customer_order.index',compact('orders','search','search_value'));
    }
    public function completed()
    {
        $orders = $this->order->where('customer_id',Auth::user()->customer->id)->where('status',2)->latest()->paginate(10);
        $search = false;
        $search_value = null;
        return view('dashboard.customer_order.index',compact('orders','search','search_value'));
    }
    
    public function pay()
    {
        $orders = $this->order->where('customer_id',Auth::user()->customer->id)->where('status',5)->latest()->paginate(10);
        $search = false;
        $search_value = null;
        return view('dashboard.customer_order.index',compact('orders','search','search_value'));
    }
    
    public function cancel()
    {
        $orders = $this->order->where('customer_id',Auth::user()->customer->id)->where('status',6)->latest()->paginate(10);
        $search = false;
        $search_value = null;
        return view('dashboard.customer_order.index',compact('orders','search','search_value'));
    }
    
    public function amount()
    {
        $orders = $this->order->where('customer_id',Auth::user()->customer->id)->where('status',7)->latest()->paginate(10);
        $search = false;
        $search_value = null;
        return view('dashboard.customer_order.index',compact('orders','search','search_value'));
    }

    

    
    
}
