<?php
    $list[0]="";
    $list[1]="mm-active";
    $list[2]="";
    $list[3]="";
?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
        <h4 class="mb-sm-0 font-size-18" id="title1">كل طلبات المندوب - <?php echo e(Auth::user()->name); ?></h4>



        

    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="card">

            <div class="card-body">
                <h4 class="mb-sm-0 font-size-18" id="title2" style="display: none">
                    <span class="logo-sm">
                        <img src="<?php echo e(URL::asset('assets/images/icon.png')); ?>" alt="" height="60">
                    </span>
                </h4>


                
                <div class="table-responsive noprint">
                    <table class="table table-editable table-nowrap align-middle table-edits">
                        <thead>
                            <?php if($search == true): ?>
                                <td colspan="6">
                                    <form action="<?php echo e(URL::route('dashboard.delivery.orders.searchOrder')); ?>" method="POST" >
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('POST'); ?>
                                        <div class="row">
                                            <div class="col-md-10">
                                                 <div class="row">
                                                     <div class="col-md-3">
                                                        <input style="border-radius: 50px;box-shadow: 3px 3px 5px #888888; " type="date" value="<?php echo e($search_value); ?>"  name="date"  class="form-control text-center" id="date" placeholder=" ابحث بتاريخ وصول الطلبات">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <input style="border-radius: 50px;box-shadow: 3px 3px 5px #888888; " type="text" value="<?php echo e($search_name); ?>"  name="name"  class="form-control text-center" id="date" placeholder=" ابحث باسم صاحب الطلب">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <input style="border-radius: 50px;box-shadow: 3px 3px 5px #888888; " type="text" value="<?php echo e($search_phone); ?>"  name="phone"  class="form-control text-center" id="date" placeholder=" ابحث برقم البوليصة">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <input style="border-radius: 50px;box-shadow: 3px 3px 5px #888888; " type="text" value="<?php echo e($search_address); ?>"  name="address"  class="form-control text-center" id="date" placeholder=" ابحث بالمحافظة">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-2">
                                                <input style="border-radius: 50px;display: inline  " type="submit" class="form-control btn btn-primary btn-sm " value="بحث">
                                            </div>
                                        </div>
                                    </form>                        
                                </td>
                                <td>
                                    <a href="<?php echo e(route('dashboard.delivery.orders.index')); ?>" class="btn btn-outline-primary btn-sm w-100" title="عرض الكل">
                                        <i class="mdi mdi-close"></i>عرض الكل
                                    </a>
                                </td>
                            <?php else: ?>
                                <td colspan="7">
                                    <form action="<?php echo e(URL::route('dashboard.delivery.orders.searchOrder')); ?>" method="POST" >
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('POST'); ?>
                                        <div class="row">
                                            <div class="col-md-9">
                                                 <div class="row">
                                                    
                                                    <div class="col-md-3">
                                                        <input style="border-radius: 50px;box-shadow: 3px 3px 5px #888888; " type="date" name="date"  class="form-control text-center" id="date" placeholder=" ابحث بتاريخ وصول الطلبات">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <input style="border-radius: 50px;box-shadow: 3px 3px 5px #888888; " type="text" name="name"  class="form-control text-center" id="date" placeholder=" ابحث باسم صاحب الطلب">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <input style="border-radius: 50px;box-shadow: 3px 3px 5px #888888; " type="text" name="phone"  class="form-control text-center" id="date" placeholder=" ابحث برقم البوليصة">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <input style="border-radius: 50px;box-shadow: 3px 3px 5px #888888; " type="text" value=""  name="address"  class="form-control text-center" id="date" placeholder=" ابحث بالمحافظة">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <input style="border-radius: 50px;display: inline  " type="submit" class="form-control btn btn-primary btn-sm " value="بحث">
                                            </div>
                                        </div>
                                    </form>                        
                                </td>
                            <?php endif; ?>
                        </thead>
                        
                        <thead class="noprint">
                            <td colspan="1">
                                <a href="<?php echo e(route('dashboard.delivery.orders.waiting')); ?>" class="btn btn-primary btn-sm w-100" title="فى الانتظار">
                                    <i class="fas fa-hashtag"></i> فى الانتظار
                                </a>
                            </td>
                            <td colspan="1">
                                <a href="<?php echo e(route('dashboard.delivery.orders.onWay')); ?>" class="btn btn-primary btn-sm w-100" title="فى الطريق">
                                    <i class="fas fa-hashtag"></i> فى الطريق
                                </a>
                            </td>
                            <td colspan="1">
                                <a href="<?php echo e(route('dashboard.delivery.orders.completed')); ?>" class="btn btn-primary btn-sm w-100" title="تم التوصيل">
                                    <i class="fas fa-hashtag"></i> تم التوصيل
                                </a>
                            </td>
                            <td colspan="1">
                                <a href="<?php echo e(route('dashboard.delivery.orders.index')); ?>" class="btn btn-primary btn-sm w-100" title="عرض الكل">
                                   <i class="fas fa-hashtag"></i> عرض الكل
                                </a>
                            </td>
                            <td colspan="2">
                            </td>
                            
                        </thead>
                        <thead>
                            <tr >
                                <th>رقم البوليصة</th>
                                <th>الاسم</th>
                                <th>سعر الطلب </th>
                                <th class="noprint">العنوان</th>
                                <th class="noprint">حالة الطلب</th>
                                <th>تاريخ  التوصيل </th>
                                <th class="noprint">العمليات</th>
                            </tr>
                        </thead>
                        <?php
                            $total = 0;
                        ?>
                        <tbody>
                           <?php if(count($orders) > 0): ?>
                                
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $total =  $total + ($order->bounce - $order->ship);
                                    if($order->status == 0 ){
                                        $status = 'فى الانتظار';  
                                    }
                                    else if($order->status == 1 ){
                                        $status = 'فى الطريق'; 
                                    }
                                    else if($order->status == 2 ){
                                        $status = 'تم التوصيل';
                                    }
                                    else if($order->status == 3 ){
                                        $status = 'ملغى من جهة المستلم';  
                                    }
                                    else if($order->status == 4 ){
                                        $status = 'ملغى من جهة المدير';
                                    }
                                ?>
                                    <tr>
                                        <td data-field="id" style="width: 170.312px;"><?php echo e($order->phone2); ?></td>
                                        <td data-field="name" style="width: 422.609px;"><?php echo e($order->name); ?> <span style="color:#00FF00"><?php if($order->bounce == $order->price): ?>&nbsp ✓ <?php endif; ?> </span></td>
                                        <td data-field="id" style="width: 170.312px;"><?php echo e($order->price + $order->ship); ?> جنية</td>
                                        <td data-field="id" style="width: 170.312px;"><?php echo e($order->address); ?></td>
                                        
                                        <td class="noprint" data-field="id" style="width: 170.312px;"><?php echo e($status); ?></td>
                                        <?php if($order->status == 2): ?>
                                            <td data-field="id" style="width: 170.312px;"><?php echo e(date('l, d M Y - h:i A', strtotime($order->done_date))); ?> </td>
                                        <?php else: ?>
                                        <td data-field="id" style="width: 170.312px;">-</td>
                                        <?php endif; ?>
                                        <td  class="noprint" style="width: 100px">
                                            <?php if($order->status == 0 ): ?>
                                                <a href="<?php echo e(URL::route('dashboard.delivery.orders.agree',$order->id)); ?>" class="btn btn-outline-info btn-sm edit" title="جاهز للتوصيل">
                                                    <i class="mdi mdi-run" title="جاهز للتوصيل"></i>
                                                </a>
                                            <?php elseif($order->status == 1 ): ?>
                                                <a href="<?php echo e(URL::route('dashboard.delivery.orders.show',$order->id)); ?>" class="btn btn-outline-info btn-sm edit" title="عرض بيانات الطلب">
                                                    <i class="far fa-eye" title="عرض بيانات الطلب"></i>
                                                </a>
                                            <?php else: ?>
                                            -
                                            <?php endif; ?>
     
                                            
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <?php else: ?>
                                <td colspan="8" class="text-center bg-primary noprint" style="color: #fff">لا يوجد طلبات الان</td>
                           <?php endif; ?>

                        </tbody>
                        
                    </table>
                    <div class="row noprint">
                        <div class="d-flex justify-content-center">
                            <?php echo e($orders->links()); ?>

                        </div>
                    </div>
                    
                </div>

            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('css'); ?>
<style>
    

    @media  print {
        .noprint {
            visibility: hidden;
        }
        .print{
            visibility: visible !important;
            display: block  !important;
        }
        #title1{
            display: none
        }
        #title2{
            text-align: center !important;
            margin-top: 5% !important;
            margin-bottom: 5%  !important;
            visibility: visible !important;
            display: block  !important;
        }
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('js'); ?>
<script>
    $(document).ready(function(){
   
        date = $('#name').val();
        console.log(date);
        getDate = $('#getDate');
        getDate.append(date);

        total = $('#total').val();
        console.log(total);
    });
</script>
<?php $__env->stopPush(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/feeltare/public_html/resources/views/dashboard/delivery_order/index.blade.php ENDPATH**/ ?>