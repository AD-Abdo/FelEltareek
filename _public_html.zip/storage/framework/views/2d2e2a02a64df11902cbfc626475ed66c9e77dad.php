
<?php
    $list[0]="";
    $list[1]="";
    $list[2]="";
    $list[3]="mm-active";
?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
        <h4 class="mb-sm-0 font-size-18">كل المديرين</h4>


        <div class="page-title-right">
            <ol class="breadcrumb m-0">
                <li class="breadcrumb-item"> 
                    <a href="<?php echo e(route('dashboard.admins.create')); ?>" class="btn btn-outline-primary btn-sm" title="اضافة مدير جديد">
                        <i class="fas fa-plus"></i>&nbsp
                        اضافة مدير جديد
                    </a>
                </li>
            </ol>
        </div>

    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-editable table-nowrap align-middle table-edits">
                        <thead>
                            <?php if($search == true): ?>
                                <td colspan="3">
                                    <form action="<?php echo e(URL::route('dashboard.admins.search')); ?>" method="POST" >
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('POST'); ?>
                                        <input style="border-radius: 50px;box-shadow: 3px 3px 5px #888888; " type="text" name="name" value="<?php echo e($search_value); ?>" class="form-control text-center" id="name" placeholder=" ابحث باسم المدير">
                                    </form>                        
                                </td>
                                <td>
                                    <a href="<?php echo e(route('dashboard.admins.index')); ?>" class="btn btn-outline-primary btn-sm w-100" title="عرض الكل">
                                        <i class="mdi mdi-close"></i>عرض الكل
                                    </a>
                                </td>
                            <?php else: ?>
                                <td colspan="4">
                                    <form action="<?php echo e(URL::route('dashboard.admins.search')); ?>" method="POST" >
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('POST'); ?>
                                        <input style="border-radius: 50px;box-shadow: 3px 3px 5px #888888; " type="text" name="name"  class="form-control text-center" id="name" placeholder=" ابحث باسم المدير">
                                    </form>                        
                                </td>
                            <?php endif; ?>
                        </thead>
                        <thead>
                            <tr >
                                <th>ID</th>
                                <th>الاسم</th>
                                <th>البريد الالكتروني</th>
                                <th>تاريخ / وقت الانشاء</th>
                            </tr>
                        </thead>
                        <?php
                            $id = 1;
                        ?>
                        <tbody>
                           <?php if(count($admins) > 0): ?>
                                <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td data-field="id" style="width: 170.312px;"><?php echo e($id++); ?></td>
                                        <td data-field="name" style="width: 422.609px;"><?php echo e($admin->name); ?></td>
                                        <td data-field="id" style="width: 170.312px;"><?php echo e($admin->email); ?></td>
                                        <td data-field="id" style="width: 170.312px;"><?php echo e(date('l, d M Y - h:i A', strtotime($admin->created_at))); ?></td>
                                        
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <?php else: ?>
                                <td colspan="4" class="text-center bg-primary" style="color: #fff">لا يوجد مديرين الان</td>
                           <?php endif; ?>

                        </tbody>
                       
                    </table>
                    <div class="row">
                        <div class="d-flex justify-content-center">
                            <?php echo e($admins->links()); ?>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u286099090/domains/fe-eltareek.com/public_html/resources/views/dashboard/admin/index.blade.php ENDPATH**/ ?>