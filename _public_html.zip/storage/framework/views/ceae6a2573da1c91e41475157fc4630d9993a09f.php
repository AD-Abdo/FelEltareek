<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            
            <div class="col-sm-12">
                <div class="text-sm-end d-none d-sm-block">
                    كل حقوق الملكية محفوظة لـــ X الطريق
                </div>
            </div>
        </div>
    </div>
</footer><?php /**PATH /home/u286099090/domains/feeltareek.com/public_html/resources/views/dashboard/layouts/footer.blade.php ENDPATH**/ ?>