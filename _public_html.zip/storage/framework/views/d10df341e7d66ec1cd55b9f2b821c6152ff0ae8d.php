
<?php
    $list[0]="";
    $list[1]="mm-active";
    $list[2]="";
    $list[3]="";
?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
        <h4 class="mb-sm-0 font-size-18">طلب العميل  <?php echo e($order->name); ?> </h4>

        <div class="page-title-right">
            <ol class="breadcrumb m-0">
                <li class="breadcrumb-item"> 
                    <a href="<?php echo e(route('dashboard.delivery.orders.index')); ?>" class="btn btn-outline-primary btn-sm" title="رجوع">
                        <i class="fas fa-arrow-left"></i>&nbsp
                    </a>
                </li>
            </ol>
        </div>

    </div>
</div>

<div class="row">
    <div class="col-xl-12">
        <div class="card">
            <div class="card-body">

                <form  action="<?php echo e(URL::route('dashboard.delivery.orders.update',$order->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?> 
                    <?php echo $__env->make('dashboard.delivery_order.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label for="total" class="form-label">المبلغ المستلم من العميل</label>
                            <input type="number" name="total" value="<?php echo e(old('total')); ?>" class="form-control" id="total" placeholder="ادخل المبلغ المستلم من العميل">
                        </div>
                            
                    </div>
                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label for="notes" class="form-label">ملاحظات</label>
                            <textarea name="notes" class="form-control w-100" id="notes" placeholder="ملاحظات الطلب"><?php echo e($order->notes ?? 'لا يوجد ملاحظات حتى الان'); ?></textarea>
                        </div>
                            
                    </div>
                       
                        
                                  
                    
                    <div class="row text-center">
                        <div class="col-md-4"></div>
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-primary w-100 btn-submit" title="تعديل">تعديل</button>
                        </div>
                        
                        <div class="col-md-4"></div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<script>
   
    $(document).ready(function(){
        $('#name').val('<?php echo e($order->name); ?>').attr('disabled',true);
        $('#customer_id').val('<?php echo e($order->customer_id); ?>').attr('disabled',true);
        $('#price').val('<?php echo e($order->price + $order->ship); ?>').attr('disabled',true);
        $('#phone1').val('<?php echo e($order->phone1); ?>').attr('disabled',true);
        $('#phone2').val('<?php echo e($order->phone2); ?>').attr('disabled',true);
        $('#address').val('<?php echo e($order->address); ?>').attr('disabled',true);
        $('#user_create').val('<?php echo e($order->UserCreate->name); ?>').attr('disabled',true);
    });
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u286099090/domains/feeltareek.com/public_html/resources/views/dashboard/delivery_order/edit.blade.php ENDPATH**/ ?>